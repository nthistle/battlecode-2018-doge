from battlecode import MapLocation as BCMapLocation
from utils import priority_dict
from collections import deque


class MapLocation(BCMapLocation):
    def __lt__(self, other):
        if self.x < other.x:
            return True
        return self.y < other.y

    def __eq__(self, other):
        return hash(self) == hash(other)

    def __hash__(self):
        return hash(self.to_json())


class Path:
    def __init__(self, unit, path, target):
        self.unit = unit
        self.path = path
        self.target = target


class PathFinder:
    def __init__(self, var, *args, **kwargs):
        self.v = var
        self.construct_graph()
        self.paths = {}

    def construct_graph(self):
        adjacencies = {}
        plan = self.v.gc.planet()
        curr_map = self.v.gc.starting_map(plan)
        for x in range(curr_map.width):
            for y in range(curr_map.height):
                loc = MapLocation(plan, x, y)
                for d in self.v.dirs:
                    new = loc.add(d)
                    new = MapLocation(new.planet, new.x, new.y)
                    if curr_map.on_map(new) and curr_map.is_passable_terrain_at(new):
                        adjacencies.setdefault(loc, set()).add(new)
        self.v.adjacencies = adjacencies

    def nearby(self, loc):
        return self.v.gc.sense_nearby_units_by_team(loc, 1, self.v.otherteam)

    def _path(self, unit, action, loc=None):
        if not loc:
            loc = unit.location.map_location()
            loc = MapLocation(loc.planet, loc.x, loc.y)
            target = self.dfs(loc, action)
        else:
            if self.nearby(loc):
                target = self.bfs(loc, action)
            else:
                target = self.dfs(loc, action, maxiter=100)
        if not target:
            return Path(unit, [], None)
        path = self.astar(loc, target)
        return Path(unit, path, target)

    def next_move(self, unit, action):
        p = self.get_path(unit, action)
        if p.path:
            return p.path.pop()
        else:
            self.paths.pop(unit.id)
            return None

    def get_path(self, unit, action):
        if unit.id not in self.paths:
            self.paths[unit.id] = self._path(unit, action)
        path = self.paths[unit.id]
        if action == self.enemy:
            try:
                self.v.gc.sense_unit_at_location(path.target)
            except Exception as e:
                new_path = self._path(unit, action, loc=path.target)
                self.paths[unit.id].path = new_path.path + self.paths[unit.id].path
                self.paths[unit.id].target = new_path.target
        return path


    def enemy(self, ml):
        if not self.v.gc.can_sense_location(ml):
            return False
        try:
            unit = self.v.gc.sense_unit_at_location(ml)
            return unit.team == self.v.otherteam
        except Exception as e:
            return False

    def invisible(self, ml):
        return not self.v.gc.can_sense_location(ml)

    def karbonite(self, ml):
        if not self.v.gc.can_sense_location(ml):
            return False
        return self.v.gc.karbonite_at(ml) > 0

    def dfs(self, start, end, maxiter=None):
        """
        @param start MapLocation
        @param end lambda MapLocation: @return bool
        @return MapLocation
        """
        open_set = deque([])
        closed_set = set()
        meta = dict()
        meta[start] = None
        open_set.append(start)
        count = 0
        while open_set:
            parent_state = open_set.pop()
            if end(parent_state):
                return parent_state
            for child_state in self.v.adjacencies[parent_state]:
                if child_state in closed_set:
                    continue
                meta[child_state] = parent_state
                open_set.append(child_state)
                closed_set.add(parent_state)
            count += 1
            if maxiter and count > maxiter:
                break

    def bfs(self, start, end):
        """
        @param start MapLocation
        @param end lambda MapLocation: @return bool
        @return MapLocation
        """
        open_set = deque([])
        closed_set = set()
        meta = dict()
        meta[start] = None
        open_set.append(start)
        while open_set:
            parent_state = open_set.popleft()
            if end(parent_state):
                return parent_state
            for child_state in self.v.adjacencies[parent_state]:
                if child_state in closed_set:
                    continue
                meta[child_state] = parent_state
                open_set.append(child_state)
                closed_set.add(parent_state)

    def get_distance(self, start, end):
        return start.distance_squared_to(end)

    def astar(self, start, end):
        openset = priority_dict()
        closedset = set()
        cameFrom = dict()
        gscore = dict()
        gscore[start] = 0
        openset[start] = (self.get_distance(start, end), self.get_distance(start, end))
        graph = self.v.adjacencies
        while openset:
            curr = openset.smallest()
            if curr == end:
                return self.reconstruct_path(cameFrom, curr)
            node = openset.pop_smallest()
            closedset.add(node)
            for edge in graph[node]:
                if edge in closedset:
                    continue
                dist = self.get_distance(edge, end)
                if edge not in openset:
                    gscore[edge] = gscore[node] + 1
                    cameFrom[edge] = node
                    openset[edge] = (gscore[edge] + dist, dist)
                if gscore[node] + 1 >= gscore[edge]:
                    continue
                cameFrom[edge] = node
                gscore[edge] = gscore[node] + 1
                openset[edge] = (gscore[edge] + dist, dist)
        return None

    def reconstruct_path(self, cameFrom, current):
        full_path = [current]
        total_distance = 0
        while current in cameFrom:
            old = current
            current = cameFrom[current]
            if current == old:
                return full_path
            full_path.append(current)
        return full_path
