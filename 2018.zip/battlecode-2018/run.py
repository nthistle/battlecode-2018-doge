import battlecode as bc
import random
import sys
import traceback
from argparse import Namespace
from path_finding import PathFinder


class Attack:
    def __init__(self, var, kar=0, members=set()):
        self.v = var
        self.kar = kar
        self.members = members
        self.leader = {}

    def update(self):
        torem = set()
        for i in self.members:
            # get unit if it still exists
            try:
                u = self.v.gc.unit(i)
            except Exception as e:
                torem.add(i)
                continue
            try:
                loc = u.location.map_location()
                attackable = self.v.gc.sense_nearby_units_by_team(loc, u.attack_range(), self.v.otherteam)
                if attackable and self.v.gc.is_attack_ready(i):
                    attackee = random.choice(attackable)
                    if self.v.gc.can_attack(i, attackee.id):
                        print('attacking', attackee.id)
                        self.v.gc.attack(i, attackee.id)
                if not self.v.gc.is_move_ready(i):
                    continue
                # decide move
                if self.v.gc.sense_nearby_units_by_team(loc, 20, self.v.otherteam):
                    next_loc = self.v.pf.next_move(u, self.v.pf.enemy)
                else:
                    next_loc = self.v.pf.next_move(u, self.v.pf.invisible)
                if next_loc is not None:
                    next_loc = bc.MapLocation(next_loc.planet, next_loc.x, next_loc.y)
                    d = loc.direction_to(next_loc)
                    if self.v.gc.can_move(i, d):
                        self.v.gc.move_robot(i, d)
                else:
                    for d in self.v.dirs:
                        if self.v.gc.can_move(i, d):
                            self.v.gc.move_robot(i, d)
                            break
            except Exception as e:
                print('attack err:', e)
                traceback.print_exc()
        self.members -= torem

    def factory(self):
        global facts, factory_claim, knight_cost
        if self.kar >= knight_cost:
            for i in facts:
                try:
                    if gc.can_produce_robot(i, bc.UnitType.Knight):
                        gc.produce_robot(i, bc.UnitType.Knight)
                        print('knighted!')
                        self.kar -= knight_cost
                        factory_claim[i].append(self)
                except Exception as e:
                    print('err attack:', e)
                    traceback.print_exc()
    def addmember(self, u):
        self.members.add(u.id)


class Harvest:
    def __init__(self, var, kar=0, members=set()):
        self.v = var
        self.kar = kar
        self.members = members
        self.building = set()
        self.wf_ratio = 2

    def update(self):
        torem = set()
        for i in self.members:

            # get unit if it still exists
            try:
                u = self.v.gc.unit(i)
            except Exception as e:
                torem.add(i)
                continue
            try:
                acted = False
                loc = u.location.map_location()
                random.shuffle(self.v.dirs)
                nearby = self.v.gc.sense_nearby_units_by_team(loc, 2, self.v.myteam)
                # build factory
                if i in self.building:
                    for other in nearby:
                        if self.v.gc.can_build(i, other.id):
                            print('built!')
                            self.v.gc.build(i, other.id)
                            if other.structure_is_built():
                                self.building.remove(i)
                            acted = True
                            break
                if acted:
                    continue
                # blueprint factory
                if self.kar >= self.v.factory_cost and len(self.v.facts) * self.wf_ratio < len(self.members):
                    for d in self.v.dirs:
                        if self.v.gc.can_blueprint(i, bc.UnitType.Factory, d):
                            print('blueprinted!')
                            self.v.gc.blueprint(i, bc.UnitType.Factory, d)
                            init_factory(loc.add(d))
                            self.kar -= factory_cost
                            self.building.add(i)
                            acted = True
                            break
                if acted:
                    continue
                # harvest karbonite
                for d in self.v.dirs:
                    if self.v.gc.can_harvest(i, d):
                        self.v.gc.harvest(i, d)
                        acted = True
                        break
                if acted:
                    continue
                if not self.v.gc.is_move_ready(i):
                    continue
                # choose move
                for d in self.v.dirs:
                    if self.v.gc.can_move(i, d):
                        self.v.gc.move_robot(i, d)
                        break
            except Exception as e:
                print('err harvest', e)
                traceback.print_exc()
        self.members -= torem

    def addmember(self, u):
        self.members.add(u.id)

    def factory(self):
        global facts, factory_claim, worker_cost, factory_cost
        if self.kar >= worker_cost and len(self.members) <= len(facts) * self.wf_ratio:
            for i in facts:
                try:
                    if gc.can_produce_robot(i, bc.UnitType.Worker):
                        gc.produce_robot(i, bc.UnitType.Worker)
                        self.kar -= worker_cost
                        factory_claim[i].append(self)
                except:
                    pass


def unload_factories():
    global ns
    torem = set()
    for i in ns.facts:
        try:
            u = ns.gc.unit(i)
        except:
            torem.add(i)
            continue
        try:
            loc = u.location.map_location()
            if len(u.structure_garrison()) >= 1:
                random.shuffle(ns.dirs)
                for d in ns.dirs:
                    if ns.gc.can_unload(i, d):
                        ns.gc.unload(i, d)
                        u = ns.gc.sense_nearby_units(loc.add(d), 0)[0]
                        ns.factory_claim[i][0].addmember(u)
                        ns.factory_claim[i].pop(0)
                        continue
        except Exception as e:
            print("factory:", e)
            traceback.print_exc()
    ns.facts -= torem


def init_factory(maploc):
    global ns
    u = ns.gc.sense_nearby_units(maploc, 0)[0]
    ns.facts.add(u.id)
    ns.factory_claim[u.id] = []


def dole_kar():
    global ns
    karinuse = sum(map(lambda a: a.kar, ns.current_acts))
    newkar = ns.gc.karbonite() - karinuse
    tot = 0
    for act in ns.current_acts:
        tot += ns.prop[act]
    for act in ns.current_acts:
        toadd = int(newkar * (ns.prop[act] / tot) + 0.4999)
        act.kar += toadd
    # dole out rest randomly?


print('starting')
gc = bc.GameController()
print('started')

random.seed(120391)
myteam = gc.team()
otherteam = bc.Team.Blue if myteam == bc.Team.Red else bc.Team.Red

# misc
dirs = list(bc.Direction)
facts = set()
factory_claim = {}

# costs
factory_cost = 100
knight_cost = 20
worker_cost = 25


ns = Namespace(gc=gc,
               myteam=myteam,
               otherteam=otherteam,
               dirs=dirs,
               facts=facts,
               factory_claim=factory_claim,
               factory_cost=factory_cost,
               knight_cost=knight_cost,
               worker_cost=worker_cost)

# set up activities
attack = Attack(ns, kar=0)
harvest = Harvest(ns, kar=100)
ns.current_acts = [attack, harvest]
ns.prop = {attack: 7, harvest: 3}
ns.pf = PathFinder(ns)

# add workers to initial activities
for unit in gc.my_units():
    harvest.members.add(unit.id)
# research

while True:
    print('round:', gc.round())
    # dole out kar for next round
    dole_kar()
    # factory produce
    unload_factories()

    for act in ns.current_acts:
        act.factory()

    # update activities
    for act in ns.current_acts:
        act.update()

    sys.stdout.flush()
    sys.stderr.flush()
    print('turn over')
    gc.next_turn()
