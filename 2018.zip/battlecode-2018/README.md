# Battlecode 2018
Make sure `run.py` is the main file. Feel free to import any other files in the same directory.
